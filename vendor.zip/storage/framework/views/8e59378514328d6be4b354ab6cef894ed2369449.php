<div class="container-fluid footer">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-center align-items-center">
                <img data-aos="zoom-in" class="footer__image" width="300" src="<?php echo e(asset('img/logo.jpg')); ?>" alt="">
            </div>
        </div>
    </div>
</div>
<div class="container-fluid footer-copyright">
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-center align-items-center">
                <p class="footer-copyright__text">Hip Hop Hooray &copy; <?php echo e(date('Y')); ?> - Design By E&M Computer Soluctions</p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\hiphop\resources\views/partials/footer.blade.php ENDPATH**/ ?>